type ExpenseRow = {
  id: number
  title: string
  amount: string | number
  category: 'Hardware' | 'Software' | 'Travel' | 'Office'
  status: 'Pending Manager' | 'Pending VP' | 'Approved' | 'Rejected'
  requester_email: string
  approval_log: string
  created_at: string
}

export default async function getExpenseRequests() {
  const result = await retoolDb.query<ExpenseRow>(`
    SELECT id, title, amount, category, status, requester_email, approval_log, created_at
    FROM expense_requests
    ORDER BY created_at DESC
  `)

  return result.data
}
