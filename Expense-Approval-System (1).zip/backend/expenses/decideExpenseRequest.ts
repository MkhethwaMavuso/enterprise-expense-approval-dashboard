type Params = {
  id: number
  action: 'approve' | 'reject'
}

type ExpenseRow = {
  id: number
  amount: string | number
  status: 'Pending Manager' | 'Pending VP'
  approval_log: string
}

function canApprove(user: User) {
  const groupMatch = user.groups.some((group) => /^(admin|manager)$/i.test(group.name))
  return groupMatch || /(^|[.+_-])(admin|manager)([.+_-]|@)/i.test(user.email)
}

export default async function decideExpenseRequest(req: { params: Params; user: User }) {
  if (!canApprove(req.user)) throw new Error('Only Admin and Manager roles can approve or reject expenses.')
  if (!Number.isInteger(req.params.id)) throw new Error('Invalid expense request.')

  const selected = await retoolDb.query<ExpenseRow>(`
    SELECT id, amount, status, approval_log
    FROM expense_requests
    WHERE id = $1 AND status IN ('Pending Manager', 'Pending VP')
  `, [req.params.id])
  const expense = selected.data[0]
  if (!expense) throw new Error('This expense request is no longer awaiting approval.')

  const now = new Intl.DateTimeFormat('en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date())
  const amount = Number(expense.amount)
  const isEscalation = req.params.action === 'approve' && amount >= 5000 && expense.status === 'Pending Manager'
  const status = req.params.action === 'reject' ? 'Rejected' : isEscalation ? 'Pending VP' : 'Approved'
  const logEntry = req.params.action === 'reject'
    ? `Rejected ${now}`
    : isEscalation
      ? `Escalated to VP ${now}`
      : `Approved by ${expense.status === 'Pending VP' ? 'VP' : 'Manager'} ${now}`

  const result = await retoolDb.query(`
    UPDATE expense_requests
    SET status = $1::VARCHAR(50), approval_log = CONCAT(COALESCE(approval_log, ''), CASE WHEN COALESCE(approval_log, '') = '' THEN '' ELSE ' • ' END, $2::TEXT)
    WHERE id = $3::INTEGER
    RETURNING id, title, amount, category, status, requester_email, approval_log, created_at
  `, [status, logEntry, expense.id])

  return result.data[0]
}
