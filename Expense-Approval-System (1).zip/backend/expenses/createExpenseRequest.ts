type Category = 'Hardware' | 'Software' | 'Travel' | 'Office'

type Params = {
  title: string
  amount: number
  category: Category
  requesterEmail: string
}

export default async function createExpenseRequest(req: { params: Params }) {
  const title = req.params.title.trim()
  const requesterEmail = req.params.requesterEmail.trim().toLowerCase()

  if (!title || title.length > 255) throw new Error('Enter a title under 255 characters.')
  if (!Number.isFinite(req.params.amount) || req.params.amount <= 0) throw new Error('Enter a positive expense amount.')
  if (!requesterEmail || requesterEmail.length > 255) throw new Error('Enter a valid requester email.')

  const now = new Intl.DateTimeFormat('en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date())
  const result = await retoolDb.query(`
    INSERT INTO expense_requests (title, amount, category, status, requester_email, approval_log)
    VALUES ($1, $2, $3, 'Pending Manager', $4, $5)
    RETURNING id, title, amount, category, status, requester_email, approval_log, created_at
  `, [title, req.params.amount, req.params.category, requesterEmail, `Submitted ${now}`])

  return result.data[0]
}
