# Enterprise Expense Approval Dashboard

A production-oriented, multi-tier expense approval application built with React, Retool backend functions, and Retool Database.

## Features

- Create expense requests with title, amount, category, and requester email.
- Persist expense records in the production Retool Database.
- Browse, search, and filter all submitted expense requests.
- Show a sequential row number for each request.
- Track summary metrics for pending requests, approved spend, VP reviews, and total submissions.
- Apply a multi-tier approval workflow:
  - Requests under $5,000 are approved by a manager.
  - Requests of $5,000 or more escalate from manager review to VP review.
  - VP-pending requests are approved by a VP.
  - Authorized reviewers can reject a request at either pending stage.
- Maintain an audit-style approval log with submission, escalation, approval, and rejection timestamps.
- Restrict decision actions to users in `Admin` or `Manager` groups, or users whose email matches the configured manager/admin convention.

## Data Model

The app stores records in the `expense_requests` PostgreSQL table in Retool Database.

| Column | Type | Description |
| --- | --- | --- |
| `id` | `SERIAL PRIMARY KEY` | Unique expense request ID |
| `title` | `VARCHAR(255)` | Expense title |
| `amount` | `NUMERIC(10,2)` | Requested amount |
| `category` | `VARCHAR(50)` | Hardware, Software, Travel, or Office |
| `status` | `VARCHAR(50)` | Pending Manager, Pending VP, Approved, or Rejected |
| `requester_email` | `VARCHAR(255)` | Requester's email address |
| `approval_log` | `TEXT` | Timestamped workflow events |
| `created_at` | `TIMESTAMP` | Submission timestamp |

## Backend Functions

All backend functions are in `/backend/expenses/`.

| Function | Purpose |
| --- | --- |
| `getExpenseRequests.ts` | Returns all expense requests, newest first. |
| `createExpenseRequest.ts` | Validates and saves a new request with `Pending Manager` status. |
| `decideExpenseRequest.ts` | Applies authorization, approval escalation, approval, or rejection rules and appends to the audit log. |

## Frontend

The primary UI is located in:

- `/frontend/pages/ExpenseApprovalDashboard.tsx`

The page loads persisted data on mount through generated backend hooks, refreshes after every mutation, and uses standard shadcn/ui components.

## Approval Rules

1. Every newly submitted request enters **Pending Manager** status.
2. A manager approval for a request below $5,000 sets its status to **Approved**.
3. A manager approval for a request of $5,000 or more sets its status to **Pending VP**.
4. A VP-stage approval sets the status to **Approved**.
5. An authorized reviewer can set either pending status to **Rejected**.

## Running and Using the App

Open the app in Retool, submit a request using the **New expense request** form, and use the table filters to locate it. Users with the appropriate role can approve or reject pending items from the table.

The app executes backend functions in the active Retool environment and uses the connected `retoolDb` resource for persistence.
