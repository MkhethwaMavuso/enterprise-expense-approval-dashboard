import ExpenseApprovalDashboard from './pages/ExpenseApprovalDashboard'

export default function App() {
  return <ExpenseApprovalDashboard />
}
