import { useEffect, useMemo, useState, type FormEvent } from 'react'
import {
  CheckCircle2,
  ChevronRight,
  ClipboardCheck,
  Clock3,
  DollarSign,
  FileText,
  Plus,
  Search,
  ShieldCheck,
  XCircle,
} from 'lucide-react'
import { useCurrentUser } from '../hooks/useCurrentUser'
import { useCreateExpenseRequest, useDecideExpenseRequest, useGetExpenseRequests } from '../hooks/backend/expenses'
import { Badge } from '../lib/shadcn/badge'
import { Button } from '../lib/shadcn/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../lib/shadcn/card'
import { Input } from '../lib/shadcn/input'
import { Label } from '../lib/shadcn/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../lib/shadcn/select'
import { Toaster, toast } from '../lib/shadcn/sonner'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../lib/shadcn/table'

type Category = 'Hardware' | 'Software' | 'Travel' | 'Office'
type ExpenseStatus = 'Pending Manager' | 'Pending VP' | 'Approved' | 'Rejected'

type ExpenseRequest = {
  id: number
  title: string
  amount: number
  category: Category
  status: ExpenseStatus
  requesterEmail: string
  approvalLog: string
  createdAt: string
}

type ExpenseForm = {
  title: string
  amount: string
  category: Category | ''
  requesterEmail: string
}

const categories: Category[] = ['Hardware', 'Software', 'Travel', 'Office']

const emptyForm: ExpenseForm = { title: '', amount: '', category: '', requesterEmail: '' }

function formatCurrency(amount: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount)
}

function formatDate(isoDate: string) {
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(isoDate))
}

function statusStyle(status: ExpenseStatus) {
  if (status === 'Approved') return 'bg-success/15 text-success border-success/30'
  if (status === 'Rejected') return 'bg-destructive/15 text-destructive border-destructive/30'
  if (status === 'Pending VP') return 'bg-warning/15 text-warning border-warning/30'
  return 'bg-muted text-muted-foreground border-border'
}

export default function ExpenseApprovalDashboard() {
  const { user, loading: userLoading } = useCurrentUser()
  const { data: savedRequests, loading: loadingRequests, error: loadError, dataAccessErrors: loadAccessErrors, trigger: loadRequests } = useGetExpenseRequests()
  const { loading: isSubmitting, trigger: createRequest } = useCreateExpenseRequest()
  const { loading: isDeciding, trigger: decideRequest } = useDecideExpenseRequest()
  const [requests, setRequests] = useState<ExpenseRequest[]>([])
  const [form, setForm] = useState<ExpenseForm>(emptyForm)
  const [searchTerm, setSearchTerm] = useState('')
  const [categoryFilter, setCategoryFilter] = useState<Category | 'all'>('all')

  useEffect(() => {
    void loadRequests()
  }, [loadRequests])

  useEffect(() => {
    if (!savedRequests) return
    const mapped = (savedRequests as Array<{
      id: number
      title: string
      amount: string | number
      category: Category
      status: ExpenseStatus
      requester_email: string
      approval_log: string
      created_at: string
    }>).map((request) => ({
      id: request.id,
      title: request.title,
      amount: Number(request.amount),
      category: request.category,
      status: request.status,
      requesterEmail: request.requester_email,
      approvalLog: request.approval_log,
      createdAt: request.created_at,
    }))
    setRequests(mapped)
  }, [savedRequests])

  const isApprover = useMemo(() => {
    if (!user) return false
    const hasRole = user.groups.some((group) => /^(admin|manager)$/i.test(group.name))
    return hasRole || /(^|[.+_-])(admin|manager)([.+_-]|@)/i.test(user.email)
  }, [user])

  const currentRole = useMemo(() => {
    if (!user) return 'Loading role…'
    const managedRole = user.groups.find((group) => /^(admin|manager|requester)$/i.test(group.name))
    if (managedRole) return managedRole.name
    return isApprover ? 'Manager' : 'Requester'
  }, [isApprover, user])

  const pendingRequests = useMemo(
    () => requests.filter((request) => request.status === 'Pending Manager' || request.status === 'Pending VP'),
    [requests],
  )

  const filteredRequests = useMemo(() => {
    const search = searchTerm.trim().toLowerCase()
    return requests.filter((request) => {
      const matchesSearch = !search || [request.title, request.requesterEmail, String(request.id)].some((value) => value.toLowerCase().includes(search))
      return matchesSearch && (categoryFilter === 'all' || request.category === categoryFilter)
    })
  }, [categoryFilter, requests, searchTerm])

  const approvedAmount = useMemo(
    () => requests.filter((request) => request.status === 'Approved').reduce((total, request) => total + request.amount, 0),
    [requests],
  )

  const submitExpense = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const amount = Number(form.amount)
    if (!form.title.trim() || !form.category || !form.requesterEmail.trim() || !Number.isFinite(amount) || amount <= 0) {
      toast.error('Complete each field with a valid positive amount.')
      return
    }

    try {
      await createRequest({ title: form.title, amount, category: form.category, requesterEmail: form.requesterEmail }).result
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Unable to save the expense request.')
      return
    }
    setForm(emptyForm)
    await loadRequests(undefined, { skipCache: true }).result
    toast.success('Expense request submitted for manager review.')
  }

  const approveRequest = async (request: ExpenseRequest) => {
    if (!isApprover) return
    const escalation = request.amount >= 5000 && request.status === 'Pending Manager'
    try {
      await decideRequest({ id: request.id, action: 'approve' }).result
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Unable to record the decision.')
      return
    }
    await loadRequests(undefined, { skipCache: true }).result
    toast.success(escalation ? 'Request escalated to VP approval.' : 'Expense request approved.')
  }

  const rejectRequest = async (request: ExpenseRequest) => {
    if (!isApprover) return
    try {
      await decideRequest({ id: request.id, action: 'reject' }).result
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Unable to record the decision.')
      return
    }
    await loadRequests(undefined, { skipCache: true }).result
    toast.success('Expense request rejected.')
  }

  return (
    <main className="min-h-screen bg-background px-4 py-6 text-foreground sm:px-6 lg:px-10 lg:py-8">
      <div className="mx-auto max-w-[1540px]">
        <header className="mb-8 flex flex-col justify-between gap-5 border-b border-border pb-6 lg:flex-row lg:items-end">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-retool-sm">
              <ClipboardCheck className="h-6 w-6" />
            </div>
            <div>
              <p className="mb-1 text-sm font-medium text-muted-foreground">Finance operations</p>
              <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Enterprise Expense Approval Dashboard</h1>
              <p className="mt-2 max-w-2xl text-sm text-muted-foreground">Submit, review, and audit purchase requests through a controlled multi-tier approval process.</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <ShieldCheck className="h-4 w-4 text-success" />
            {userLoading ? 'Checking access…' : `${currentRole} role · ${isApprover ? 'Approver access enabled' : 'Requester access'}`}
          </div>
        </header>

        <section className="mb-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Card className="border-border shadow-retool-sm">
            <CardContent className="flex items-center justify-between p-5">
              <div><p className="text-sm text-muted-foreground">Awaiting decision</p><p className="mt-1 text-3xl font-semibold">{pendingRequests.length}</p></div>
              <div className="rounded-lg bg-warning/15 p-3"><Clock3 className="h-5 w-5 text-warning" /></div>
            </CardContent>
          </Card>
          <Card className="border-border shadow-retool-sm">
            <CardContent className="flex items-center justify-between p-5">
              <div><p className="text-sm text-muted-foreground">Approved amount</p><p className="mt-1 text-3xl font-semibold">{formatCurrency(approvedAmount)}</p></div>
              <div className="rounded-lg bg-success/15 p-3"><DollarSign className="h-5 w-5 text-success" /></div>
            </CardContent>
          </Card>
          <Card className="border-border shadow-retool-sm">
            <CardContent className="flex items-center justify-between p-5">
              <div><p className="text-sm text-muted-foreground">VP reviews</p><p className="mt-1 text-3xl font-semibold">{requests.filter((request) => request.status === 'Pending VP').length}</p></div>
              <div className="rounded-lg bg-primary/10 p-3"><ChevronRight className="h-5 w-5 text-primary" /></div>
            </CardContent>
          </Card>
          <Card className="border-border shadow-retool-sm">
            <CardContent className="flex items-center justify-between p-5">
              <div><p className="text-sm text-muted-foreground">Submitted this period</p><p className="mt-1 text-3xl font-semibold">{requests.length}</p></div>
              <div className="rounded-lg bg-muted p-3"><FileText className="h-5 w-5 text-muted-foreground" /></div>
            </CardContent>
          </Card>
        </section>

        <section className="grid gap-6 xl:grid-cols-[380px_minmax(0,1fr)]">
          <Card className="h-fit border-border shadow-retool-sm">
            <CardHeader className="border-b border-border">
              <div className="flex items-center justify-between"><CardTitle>New expense request</CardTitle><Plus className="h-5 w-5 text-muted-foreground" /></div>
              <CardDescription>Requests are routed to a manager first. Requests of $5,000 or more then require VP approval.</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <form id="newExpenseForm" name="newExpenseForm" className="space-y-5" onSubmit={submitExpense}>
                <div className="space-y-2"><Label htmlFor="expense-title">Title</Label><Input id="expense-title" value={form.title} onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))} placeholder="e.g. Team offsite travel" /></div>
                <div className="space-y-2"><Label htmlFor="expense-amount">Amount</Label><div className="relative"><DollarSign className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><Input id="expense-amount" className="pl-9" type="number" min="0.01" step="0.01" value={form.amount} onChange={(event) => setForm((current) => ({ ...current, amount: event.target.value }))} placeholder="0.00" /></div></div>
                <div className="space-y-2"><Label>Category</Label><Select value={form.category} onValueChange={(value) => setForm((current) => ({ ...current, category: value as Category }))}><SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger><SelectContent>{categories.map((category) => <SelectItem key={category} value={category}>{category}</SelectItem>)}</SelectContent></Select></div>
                <div className="space-y-2"><Label htmlFor="requester-email">Requester email</Label><Input id="requester-email" type="email" value={form.requesterEmail} onChange={(event) => setForm((current) => ({ ...current, requesterEmail: event.target.value }))} placeholder="name@company.com" /></div>
                <Button type="submit" className="w-full" disabled={isSubmitting}>{isSubmitting ? 'Submitting…' : <><Plus className="mr-2 h-4 w-4" />Submit expense request</>}</Button>
              </form>
            </CardContent>
          </Card>

          <Card className="min-w-0 border-border shadow-retool-sm">
            <CardHeader className="gap-5 border-b border-border pb-5 lg:flex-row lg:items-end lg:justify-between">
              <div><CardTitle>Expense requests</CardTitle><CardDescription className="mt-1">All submitted requests and their latest approval status.</CardDescription></div>
              <div className="grid w-full gap-3 sm:grid-cols-[minmax(0,1fr)_170px] lg:max-w-xl">
                <div className="relative"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><Input className="pl-9" value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="Search requests" /></div>
                <Select value={categoryFilter} onValueChange={(value) => setCategoryFilter(value as Category | 'all')}><SelectTrigger><SelectValue placeholder="All categories" /></SelectTrigger><SelectContent><SelectItem value="all">All categories</SelectItem>{categories.map((category) => <SelectItem key={category} value={category}>{category}</SelectItem>)}</SelectContent></Select>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {loadError ? <div className="border-b border-destructive/30 bg-destructive/10 px-6 py-3 text-sm text-destructive">Unable to load expense requests: {loadError}</div> : null}
              {!loadError && loadAccessErrors.length > 0 ? <div className="border-b border-warning/30 bg-warning/10 px-6 py-3 text-sm text-warning">{loadAccessErrors.map((error) => error.message).join('; ')}</div> : null}
              {!isApprover && !userLoading ? <div className="flex items-center gap-2 border-b border-border bg-muted/40 px-6 py-3 text-sm text-muted-foreground"><ShieldCheck className="h-4 w-4" />You are signed in as {currentRole}. Approval actions are available to Admin and Manager roles only.</div> : null}
              <Table id="expensesTable">
                <TableHeader><TableRow><TableHead className="w-14">#</TableHead><TableHead>Request</TableHead><TableHead>Category</TableHead><TableHead>Submitted</TableHead><TableHead className="text-right">Amount</TableHead><TableHead>Status</TableHead>{isApprover ? <TableHead className="text-right">Actions</TableHead> : null}</TableRow></TableHeader>
                <TableBody>
                  {filteredRequests.map((request, index) => <TableRow key={request.id}>
                    <TableCell className="font-mono text-xs text-muted-foreground">{index + 1}</TableCell>
                    <TableCell><div className="font-medium">{request.title}</div><div className="mt-1 text-xs text-muted-foreground">#{request.id} · {request.requesterEmail}</div></TableCell>
                    <TableCell><span className="text-sm">{request.category}</span></TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">{formatDate(request.createdAt)}</TableCell>
                    <TableCell className="text-right font-medium tabular-nums">{formatCurrency(request.amount)}</TableCell>
                    <TableCell><Badge variant="outline" className={statusStyle(request.status)}>{request.status}</Badge></TableCell>
                    {isApprover ? <TableCell><div className="flex justify-end gap-2"><Button size="sm" disabled={isDeciding} onClick={() => approveRequest(request)}><CheckCircle2 className="mr-1.5 h-3.5 w-3.5" />Approve</Button><Button size="sm" disabled={isDeciding} variant="outline" className="text-destructive hover:bg-destructive/10 hover:text-destructive" onClick={() => rejectRequest(request)}><XCircle className="mr-1.5 h-3.5 w-3.5" />Reject</Button></div></TableCell> : null}
                  </TableRow>)}
                  {filteredRequests.length === 0 ? <TableRow><TableCell colSpan={isApprover ? 7 : 6} className="h-36 text-center text-muted-foreground">{loadingRequests ? 'Loading expense requests…' : 'No expense requests match the selected filters.'}</TableCell></TableRow> : null}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </section>
      </div>
      <Toaster position="bottom-right" />
    </main>
  )
}
